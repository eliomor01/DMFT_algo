# DMFT
Dynamical mean-field theory (DMFT) with the iterated perturbation theory approximation (IPT)
