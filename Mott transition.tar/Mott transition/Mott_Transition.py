import numpy as np
import matplotlib.pyplot as plt
from DMFT_IPT import *


U_list = [0.5, 1.0, 1.5, 2.0, 2.5, 2.6, 2.7, 2.8, 2.9, 3.0, 3.5, 4.0]
beta = 100
Z_list = []

for j, u0 in enumerate(U_list):

    with open('.\\input.txt', 'w') as writer:

        # if j == 0:
        #     writer.write(f'1.0 \n{u0} \n500 \n0.5 \n2000 \n{beta} \n1e-8 \n0')
            
        # else:
        #     writer.write(f'1.0 \n{u0} \n500 \n0.5 \n2000 \n{beta} \n1e-8 \n2')  

        if u0 <= 2.6:
            writer.write(f'1.0 \n{u0} \n500 \n0.5 \n2000 \n{beta} \n1e-8 \n0')
            
        else:
            writer.write(f'1.0 \n{u0} \n500 \n0.5 \n2000 \n{beta} \n1e-8 \n1')   
            
    print('----------------------------------------')
    print(f'DMFT loop for U = {u0}, beta = {beta}')
    print('----------------------------------------')
    print(' ')

    # if j == 0:
    #     Romega, Momega, tau, G_loc, S_imp, G_tau, spectral = DMFT_loop(input = '.\\input.txt', DOS_file = None, first_ite = False)
    # else:
    #     Romega, Momega, tau, G_loc, S_imp, G_tau, spectral = DMFT_loop(input = '.\\input.txt', DOS_file = None,
    #         Sigma_file =f'.\\files\\g_tau_u{np.round(U_list[j-1],1)}_beta{np.round(beta,0)}.dat', first_ite = False)

    Romega, Momega, tau, G_loc, S_imp, G_tau, spectral = DMFT_loop(input = '.\\input.txt', DOS_file = None, first_ite = False)
    
    if u0 <= 2.6:
        b= (np.imag(S_imp[Momega>0][1]) - np.imag(S_imp[Momega>0][0])) / (2*np.pi/beta)
        Z_list.append(1/(1-b))

    path1 = f'.\\files\\g_loc_u{np.round(u0,1)}_beta{np.round(beta,0)}.dat'
    with open(path1, 'w') as writer:

        for i in range(len(Momega)//2):
            writer.write(str(Momega[Momega>0][i]) + ' ' + str(np.real(G_loc[Momega>0][i])) + ' ' + str(np.imag(G_loc[Momega>0][i])) +'\n')

    path2 = f'.\\files\\sigma_u{np.round(u0,1)}_beta{np.round(beta,0)}.dat'
    with open(path2, 'w') as writer:

        for i in range(len(Momega)//2):
            writer.write(str(Momega[Momega>0][i]) + ' ' + str(np.real(S_imp[Momega>0][i])) + ' ' + str(np.imag(S_imp[Momega>0][i])) +'\n')

    path3 = f'.\\files\\g_tau_u{np.round(u0,1)}_beta{np.round(beta,0)}.dat'
    with open(path3, 'w') as writer:

        for i in range(len(tau)):
            writer.write(str(tau[i]) + ' ' + str(np.real(G_tau[i])) + ' ' + str(np.imag(G_tau[i])) +'\n')

    path4 = f'.\\files\\spectral_u{np.round(u0,1)}_beta{np.round(beta,0)}.dat'
    with open(path4, 'w') as writer:

        for i in range(len(Romega)):
            writer.write(str(Romega[i]) + ' ' + str(np.real(spectral[i])) + ' ' + str(np.imag(spectral[i])) +'\n')


path5 = f'.\\files\\Z_beta{np.round(beta,0)}.dat'
with open(path5, 'w') as writer:

    for i in range(len(Z_list)):
        writer.write(str(U_list[i]) + ' ' + str(Z_list[i]) +'\n')