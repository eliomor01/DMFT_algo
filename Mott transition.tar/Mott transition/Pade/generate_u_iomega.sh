#!/bin/bash

#set -x

bin_dir=/Users/casula/codes/dmft_codes/Code_Pade

for i in 10 20 30 40 50 
do

head -$i g_loc.dat > g_loc_$i.dat

$bin_dir/anal_cont -if=g_loc_$i.dat -inener=imag -emin=-4.0 -emax=4.0 -eta=0.01 -npoints=100

done
